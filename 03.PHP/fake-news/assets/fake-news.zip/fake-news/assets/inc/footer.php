<footer id="main-footer">
	<p>Fake News - Assignment 1 (PHP) YRGO - Fredrik Leemann</p>
</footer>
<!-- Import javascript-function to handle likes and like-buttons -->
<script src="./assets/js/app.js" type="text/javascript"></script>
